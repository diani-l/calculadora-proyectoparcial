import React from "react";
import "./App.css";

function App() {
  return (
    <div className="calculadora-container">
      <input type="text" id="resultado" readOnly />

      {/* Botones numéricos y operaciones */}
      <div className="botones">
        <button>7</button>
        <button>8</button>
        <button>9</button>
        <button>+</button>
        <br />
        <button>4</button>
        <button>5</button>
        <button>6</button>
        <button>-</button>
        <br />
        <button>1</button>
        <button>2</button>
        <button>3</button>
        <button>x</button>
        <br />
        <button>0</button>
        <button>.</button>
        <button>=</button>
        <button>C</button>
      </div>

      <h2>Conversiones</h2>

      {/* Botones de conversiones */}
      <div className="conversiones">
        <button>Hora:Min:Seg</button>
        <button>Días/Meses/Años</button>
        <button>Kg</button>
        <button>g</button>
        <button>Lb</button>
        <button>°C</button>
        <button>°F</button>
        <button>K</button>
        <button>USD</button>
        <button>COP</button>
        <button>EUR</button>
      </div>
    </div>
  );
}

export default App;
